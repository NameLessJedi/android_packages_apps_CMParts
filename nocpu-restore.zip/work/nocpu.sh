#!/sbin/sh
echo "" >/data/.nocpu
